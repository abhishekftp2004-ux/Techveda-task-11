import numpy as np

# Task 11 - NumPy Vectorization and Broadcasting

arr = np.array([10, 20, 30, 40, 50])
print("Add 5:", arr + 5)
print("Multiply by 2:", arr * 2)
print("Square:", arr ** 2)

a = np.array([10, 20, 30, 40])
b = np.array([1, 2, 3, 4])
print("Addition:", a + b)
print("Subtraction:", a - b)
print("Multiplication:", a * b)

marks = np.array([60, 70, 80, 90])
print("Marks + 5:", marks + 5)

matrix = np.array([[10,20,30],[40,50,60],[70,80,90]])
row = np.array([1,2,3])
column = np.array([[10],[20],[30]])
print("Row broadcasting:\n", matrix + row)
print("Column broadcasting:\n", matrix + column)

student_marks = np.array([[78,82,91],[65,74,80],[88,90,95],[55,68,72]])
print("Updated marks:\n", student_marks + 5)

values = np.array([10,20,30,40,50])
loop_result = []
for x in values:
    loop_result.append(x * 2)
vectorized_result = values * 2
print("Loop:", loop_result)
print("Vectorized:", vectorized_result)
